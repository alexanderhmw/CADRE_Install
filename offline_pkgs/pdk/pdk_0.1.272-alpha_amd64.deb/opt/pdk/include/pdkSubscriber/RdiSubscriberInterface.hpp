#pragma once

#include <functional>
#include "pdk_RadarDetectionImage.pb.h"
#include "pdk_RadarStatus.pb.h"

namespace PDK
{
  class CRdiInterface
  {
  public:
    void SetRDICallback(std::function<void(const class pb::PDK::RadarDetectionImage*)> callback);
    void SetRadarStatusCallback(std::function<void(const class pb::PDK::RadarStatus*)> callback);
  };
}
