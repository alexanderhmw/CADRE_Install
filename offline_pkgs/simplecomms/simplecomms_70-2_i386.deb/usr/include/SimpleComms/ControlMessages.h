/**
 * @file      ControlMessages.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_CONTROLMESSAGES_H_
#define _SIMPLECOMMS_CONTROLMESSAGES_H_

#include <stdint.h>

#include "Constants.h"
#include "TimeStamp.h"

namespace SimpleComms
{

namespace ControlMessages
{
    enum ControlMessageTypes
    {
        Connect,
        Disconnect,
        Subscribe,
        Unsubscribe,
        SubscriptionList
    };
}

namespace Transports
{
    enum TransportTypes
    {
        UnixDomainSocket,
        UDP,
        TCP
    };
}

const char *transportName(const Transports::TransportTypes &transport);

struct ConnectionMessage 
{
    ControlMessages::ControlMessageTypes type;
    Transports::TransportTypes transport;
    struct timeval offerEpoch;
} __attribute__((packed));

struct ConnectionMessageIPV4
{
    ControlMessages::ControlMessageTypes type;
    Transports::TransportTypes transport;
    struct timeval offerEpoch;
    uint32_t inetAddr;
    uint16_t inetPort;
} __attribute__((packed));

struct DisconnectionMessage 
{
    ControlMessages::ControlMessageTypes type;
    Transports::TransportTypes transport;
} __attribute__((packed));

struct SubscriptionMessage 
{
    ControlMessages::ControlMessageTypes type;
    char channel[MAX_NULL_TERM_CHANNEL_NAME];
} __attribute__((packed));

struct SubscriptionListMessage 
{
    ControlMessages::ControlMessageTypes type;
    uint16_t numChannels;
    char channel[999][MAX_NULL_TERM_CHANNEL_NAME];
} __attribute__((packed));

}

#endif
