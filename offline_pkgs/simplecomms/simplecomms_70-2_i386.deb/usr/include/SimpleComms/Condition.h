/**
 * @file    Condition.h
 * @author  Tugrul Galatali
 * @date    10/16/2006
 *
 * @attention Copyright (c) 2006
 * @attention Carnegie Mellon University
 * @attention All rights reserved.
 */
#ifndef _CONDITION_H_
#define _CONDITION_H_

#include <pthread.h>
#include <boost/noncopyable.hpp>

class Condition : boost::noncopyable {
    public:
        Condition();
        ~Condition();

        bool init();

        void set();
        void unset();

        bool isSet();

        friend bool operator==(const Condition &a, const Condition &b);

        friend class Monitor;
    private:
        pthread_mutex_t pipeMutex_;
        volatile bool set_;
        int pipe_[2];
};

#endif
