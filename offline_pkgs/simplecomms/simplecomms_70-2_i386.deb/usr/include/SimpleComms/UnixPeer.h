/**
 * @file      UnixPeer.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_UNIXPEER_H_
#define _SIMPLECOMMS_UNIXPEER_H_

#include "BasePeer.h"

namespace SimpleComms
{

class UnixPeer : public BasePeer
{
    public:
        UnixPeer(const std::string &path,
                 const TimeStamp &staleFragmentPruningThreshold
                );
        virtual ~UnixPeer();

        virtual Status::States connect();
        virtual Status::States disconnect();

        virtual Status::States getConnectionInfo(Message &msg);

    protected:
        virtual bool clientConnect(const ClientDataPtr &namedClient, const ConnectionMessage *);
};

}

#endif
