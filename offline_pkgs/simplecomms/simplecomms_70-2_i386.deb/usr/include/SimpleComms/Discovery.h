/**
 * @file      Discovery.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_DISCOVERY_H_
#define _SIMPLECOMMS_DISCOVERY_H_

#include <string>
#include <vector>

#include <boost/shared_ptr.hpp>

#include "Peer.h"
#include "Status.h"

namespace SimpleComms
{

class Discovery
{
    public:
        virtual ~Discovery()
        {
        }

        virtual Status::States initialize() = 0;
        virtual Status::States isActive() = 0;
        virtual Status::States terminate() = 0;

        virtual Status::States registerLocalPeeringMethod(const PeerPtr localPeer) = 0;
        virtual Status::States unregisterLocalPeeringMethod(const PeerPtr localPeer) = 0;
        virtual Status::States registerRemotePeeringMethod(const PeerPtr remotePeer) = 0;
        virtual Status::States unregisterRemotePeeringMethod(const PeerPtr remotePeer) = 0;
};

typedef boost::shared_ptr<Discovery> DiscoveryPtr;

}

#endif
