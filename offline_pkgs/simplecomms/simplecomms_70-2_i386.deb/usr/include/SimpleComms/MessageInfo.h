/**
 * @file      MessageInfo.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_MESSAGEINFO_H_
#define _SIMPLECOMMS_MESSAGEINFO_H_

#include <string>

#include "TimeStamp.h"

struct MessageInfo
{
    std::string origin;
    TimeStamp sendMsgTime, msgReadyTime;
};

#endif
