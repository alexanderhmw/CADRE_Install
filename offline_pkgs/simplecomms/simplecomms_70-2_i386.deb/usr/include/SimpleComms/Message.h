/**
 * @file      Message.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_MESSAGE_H_
#define _SIMPLECOMMS_MESSAGE_H_

#include <stdint.h>
#include <zlib.h>
#include <string.h>

#include <boost/shared_ptr.hpp>

#include "Constants.h"
#include "TimeStamp.h"

namespace SimpleComms
{

struct MessageHeader
{
    MessageHeader() { }

    char origin[MAX_NULL_TERM_CLIENT_NAME];
    char channel[MAX_NULL_TERM_CHANNEL_NAME];
    struct timeval sendMsgTime;
    uint32_t length;
    uint32_t rollingMessageID;
    uint32_t totalPages;

    uint32_t pageNumber;
    uint32_t dataLength;
    uint32_t headerChecksum;
    uint32_t dataChecksum;

    uint32_t MessageLength() const
    {
        return sizeof(MessageHeader) + dataLength;
    }
} __attribute__((packed));

struct Message : MessageHeader
{
    Message() { }

    unsigned char data[MAX_FRAGMENT_PAYLOAD];
} __attribute__((packed));

struct MessageBase : MessageHeader
{
    MessageBase() { }

    unsigned char *data;
};

struct MessageStub : MessageHeader
{
    MessageStub() { }
    MessageStub(const Message &source)
    {
        memcpy(this, &source, source.MessageLength());
    }

    unsigned char data[0];

    void *operator new(const unsigned int size)
    {
        return ::operator new(size);
    }

    void *operator new(const unsigned int size, const unsigned int dataLength)
    {
        return ::operator new(size + dataLength);
    }

    void operator delete(void *retired)
    {
        ::operator delete(retired);
    }
};

typedef boost::shared_ptr<MessageStub> MessagePtr;

#include "Message.def.h"

}

#endif
