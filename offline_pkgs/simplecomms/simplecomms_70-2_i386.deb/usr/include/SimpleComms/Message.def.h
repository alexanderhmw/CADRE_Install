/**
 * @file      Message.def.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */

template <typename T>
bool messageComputeChecksum(T &msg, uint32_t &newHeaderChecksum, uint32_t &newDataChecksum, const bool headerOnly = false)
{
    if (msg.dataLength <= MAX_FRAGMENT_PAYLOAD)
    {
        const uint32_t oldHeaderChecksum = msg.headerChecksum;
        const uint32_t oldDataChecksum = msg.dataChecksum;

        msg.headerChecksum = 0;

        if (!headerOnly)
        {
            // Adler is faster and good enough for our purposes with enough data
            // http://www.zlib.net/zlib_tech.html
            if (msg.dataLength > 1024)
            {
                newDataChecksum = adler32(0, reinterpret_cast<const Bytef *>(msg.data), msg.dataLength);
            }
            else
            {
                newDataChecksum = crc32(0, reinterpret_cast<const Bytef *>(msg.data), msg.dataLength);
            }

            msg.dataChecksum = newDataChecksum;
        }

        newHeaderChecksum = crc32(0, 
                                  reinterpret_cast<const Bytef *>(&msg), 
                                  sizeof(MessageHeader)
                                 );

        msg.headerChecksum = oldHeaderChecksum;
        msg.dataChecksum = oldDataChecksum;

        return true;
    }

    return false;
}

template <typename T>
bool messageSetChecksum(T &msg)
{
    uint32_t newHeaderChecksum = 0, newDataChecksum = 0;
    const bool status = messageComputeChecksum(msg, newHeaderChecksum, newDataChecksum);

    if (status)
    {
        msg.headerChecksum = newHeaderChecksum;
        msg.dataChecksum = newDataChecksum;
    }

    return status;
}

template <typename T>
bool messageValidateHeaderChecksum(T &msg)
{
    uint32_t newHeaderChecksum = 0, newDataChecksum = 0;
    const bool status = messageComputeChecksum(msg, newHeaderChecksum, newDataChecksum, true);
    assert(newDataChecksum == 0);

    return status && (msg.headerChecksum == newHeaderChecksum);
}

template <typename T>
bool messageValidateChecksum(T &msg)
{
    uint32_t newHeaderChecksum = 0, newDataChecksum = 0;
    const bool status = messageComputeChecksum(msg, newHeaderChecksum, newDataChecksum);

    return status && (msg.headerChecksum == newHeaderChecksum) && (msg.dataChecksum == newDataChecksum);
}

