/**
 * @file      Client.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_CLIENT_H_
#define _SIMPLECOMMS_CLIENT_H_

#include <string>
#include <vector>

#include "Condition.h"
#include "MessageInfo.h"
#include "Status.h"

namespace SimpleComms
{

class Client
{
    public:
        virtual ~Client()
        {
        }

        virtual Status::States connect() = 0;
        virtual Status::States disconnect() = 0;

        virtual Status::States subscribe(const std::string &channel, const uint32_t maxReceiveDepth = 0) = 0;
        virtual Status::States unsubscribe(const std::string &channel) = 0;

        virtual Status::States sendMsg(const std::string &channel, const std::string &data) = 0;
        virtual Status::States receiveMsg(const std::string &channel, std::string &data, MessageInfo &msgInfo) = 0;
        virtual Status::States receiveMsg(const std::string &channel, std::string &data) = 0;

        virtual Condition &getMessagesAvailableCondition() = 0;
};

}

#endif
