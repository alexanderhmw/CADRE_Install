/**
 * @file    Monitor.h
 * @author  Tugrul Galatali
 * @date    10/16/2006
 *
 * @attention Copyright (c) 2006
 * @attention Carnegie Mellon University
 * @attention All rights reserved.
 */
#ifndef _MONITOR_H_
#define _MONITOR_H_

#include <map>
#include <vector>

#include "TimeStamp.h"
#include "Condition.h"

class Monitor {
    public:
        Monitor();
        ~Monitor();

        void add(Condition &c);
        void remove(Condition &c);

        std::vector<Condition *> wait(const TimeStamp &timeout);

    private:
        std::map<int, Condition *> conditions;
};

#endif
