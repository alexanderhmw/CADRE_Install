/**
 * @file      Status.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_STATUS_H_
#define _SIMPLECOMMS_STATUS_H_

namespace SimpleComms
{
    namespace Status
    {
        enum States
        {
            Ok,
            Error,
            AlreadyConnected,
            SocketPathTooLong,
            ErrorCreatingSocket,
            ErrorBindingSocket,
            ErrorConnectingSocket,
            ErrorListeningSocket,
            NotConnected,
            NewData,
            ChannelNameTooLong,
            InvalidHandle
        };
    }
}

#endif
