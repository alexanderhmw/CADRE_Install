/**
 * @file    NetworkIntfUtils.h
 * @author  Tugrul Galatali
 * @date    03/10/2007
 *
 * @attention Copyright (c) 2006
 * @attention Carnegie Mellon University
 * @attention All rights reserved.
 */
#ifndef _NETWORKINTFUTILS_H_
#define _NETWORKINTFUTILS_H_

#include <stdint.h>
#include <map>
#include <string>
#include <string.h>

namespace NetworkIntfUtils
{

    typedef std::map<std::string, uint32_t> IntfNameAddrMap;

    bool GetInterfaceAddresses(IntfNameAddrMap &intfs);

    enum ParameterTypes
    {
        Address,
        Netmask,
        Broadcast
    };

    bool GetInterfaceParameter(const std::string &name, const ParameterTypes &type, unsigned int &value);
}

#endif
