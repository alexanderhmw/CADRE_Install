/**
 * @file      UdpPeer.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_UDPPEER_H_
#define _SIMPLECOMMS_UDPPEER_H_

#include "BasePeer.h"

namespace SimpleComms
{

class UdpPeer : public BasePeer
{
    public:
        UdpPeer(const std::string &advertisedIntf, 
                const uint16_t port,
                const TimeStamp &staleFragmentPruningThreshold
               );
        virtual ~UdpPeer();

        virtual Status::States connect();
        virtual Status::States disconnect();

        virtual Status::States getConnectionInfo(Message &msg);

    protected:
        const std::string &advertisedIntf_;
        const uint16_t port_;

        bool clientConnect(const ClientDataPtr &namedClient, const ConnectionMessage *connMsg);
};

}

#endif
