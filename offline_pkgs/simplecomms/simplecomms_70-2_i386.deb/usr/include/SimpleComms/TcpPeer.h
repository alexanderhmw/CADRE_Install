/**
 * @file      TcpPeer.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_TCPPEER_H_
#define _SIMPLECOMMS_TCPPEER_H_

#include "BasePeer.h"

namespace SimpleComms
{

class TcpPeer : public BasePeer
{
    public:
        TcpPeer(const std::string &advertisedIntf, 
                const uint16_t port, 
                const int backLog, 
                const TimeStamp &staleFragmentPruningThreshold
               );
        virtual ~TcpPeer();

        virtual Status::States connect();
        virtual Status::States disconnect();

        virtual Status::States getConnectionInfo(Message &msg);

        virtual Status::States receiveMsg(const BaseClientPtr &clientHandle, MessagePtr &msg);

        virtual Status::States getNamedReadHandles(BaseClientList &readHandles);

        virtual Status::States handleErrors(BaseClientList &errorHandles);

    protected:
        const std::string &advertisedIntf_;
        uint16_t port_;
        int backLog_;

        class InboundClientDataTCP : public BaseClientType
        {
            public:
                InboundClientDataTCP(BasePeer *bp, const int fd) : fd(fd), msgBufIndex(0), bp_(bp) { }
                virtual ~InboundClientDataTCP() { }

                virtual Peer *getParentPeer() { return bp_; }
                virtual std::string getName() { return ""; }
                virtual int getReadHandle() { return fd; }
                virtual int getWriteHandle() { return -1; }
                virtual bool isReadyToWrite() { return false; }
                virtual void setReadyToWrite() { }
                virtual bool hasDataToWrite() { return false; }
                virtual void setOnWriteQueue() { }
                virtual void setOffWriteQueue() { }
                virtual bool isOnWriteQueue() { return false; }

                int fd;
                MessageStub msgHeaderBuf;
                MessagePtr msg;
                uint32_t msgBufIndex;

            private:
                BasePeer *bp_;
        };

        typedef boost::shared_ptr<InboundClientDataTCP> InboundClientDataTCPPtr;
        typedef std::vector<InboundClientDataTCPPtr> InboundClientList;

        InboundClientList inboundClients_;
        void inboundClientReset(const InboundClientDataTCPPtr &inboundClient);

        virtual bool clientConnect(const ClientDataPtr &namedClient, const ConnectionMessage *connMsg);
};

}

#endif
