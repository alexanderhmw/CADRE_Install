/**
 * @file      Constants.h
 * @author    Tugrul Galatali
 * @date      02/10/2007
 *
 * @attention Copyright (C) 2007
 * @attention Carnegie Mellon University
 * @attention All rights reserved
 */
#ifndef _SIMPLECOMMS_CONSTANTS_H_
#define _SIMPLECOMMS_CONSTANTS_H_

#define MAX_NULL_TERM_CHANNEL_NAME 64
#define MAX_NULL_TERM_CLIENT_NAME 64

#define MAX_FRAGMENT_PAYLOAD 64000U

#define SIMPLECOMMS_CONTROL_CHANNEL "SimpleComms"
#define SIMPLECOMMS_STATS_CHANNEL "SimpleCommsStats"

#endif
