/**
 * @file    PThreadLocker.h
 * @author  Tugrul Galatali
 * @date    08/24/2006
 *
 * @attention Copyright (c) 2006
 * @attention Carnegie Mellon University
 * @attention All rights reserved.
 */
#ifndef _PTHREADLOCKER_H_
#define _PTHREADLOCKER_H_

#include <pthread.h>
#include <boost/noncopyable.hpp>

/**
 * @brief PThreadLocker provides "automatic" unlocking on loss of scope.
 *
 * Modelled on QT's QMutexLocker, declare it in a scope where exclusive access of a resource is neeeded. Upon exit from
 * that scope, the variable is descoped, the destructor is called and the mutex is unlocked. Useful for blocks with
 * multiple exit points.
 *
 */
class PThreadLocker : public boost::noncopyable
{
    public:
        PThreadLocker(pthread_mutex_t *m) : m(m) 
        { 
            pthread_mutex_lock(m); 
        }

        ~PThreadLocker() 
        {
            pthread_mutex_unlock(m); 
        }

    private:
        pthread_mutex_t *m;
};

#endif
