/**
 * @file      TimeStamp.h
 * @author    Tugrul Galatali (tugrul@galatali.com)
 * @date      09/10/2006
 *
 * @attention Copyright (C) 2006
 * @attention Carnegie Mellon University
 * @attention All rights reserved.
 */
#ifndef _TIME_H_TIMESTAMP_H_
#define _TIME_H_TIMESTAMP_H_

#include <sys/time.h>
#include <time.h>

#include <stdint.h>

/**
 * @brief Basic time stamp class
 *
 * A simple time stamp class founded on the veteran struct timeval plus some convenience functions.
 *
 * The issue of abstract time hasn't really been discussed yet, but the stamp itself hopefully doesn't need to be 
 * abstract.
 */
struct TimeStamp : public timeval 
{
    TimeStamp();
    TimeStamp(const time_t &s, const suseconds_t &us);
    TimeStamp(const double &time_s);
    TimeStamp(const struct timeval &tv);

    operator double () const;

    TimeStamp operator+ (const TimeStamp &m) const;
    TimeStamp operator- (const TimeStamp &m) const;
    TimeStamp operator+ (const double &time_s) const;
    TimeStamp operator- (const double &time_s) const;

    bool operator== (const TimeStamp &m) const;
    bool operator!= (const TimeStamp &m) const;
    bool operator< (const TimeStamp &m) const;
    bool operator<= (const TimeStamp &m) const;
    bool operator> (const TimeStamp &m) const;
    bool operator>= (const TimeStamp &m) const;

    bool setNow();

    void normalize();

    template<class Archive>
    void serialize(Archive &ar, const unsigned int /* file_version */);
};

#include "TimeStamp.def.h"

#endif //ifndef _TIMESTAMP_H_
